<!-- Footer -->
<footer class="footer-col d-flex justify-content-between col-sm-12 col-md-12 col-lg-12">
    <div class="footer-text">
        <p style="color: white;">2021 Coin Counter Machine</p>
    </div>
    <div class="footer-text"><a href="1index.php" id="line">About</a> &nbsp;&nbsp;&nbsp;
        <a href="1index.php#services-section" id="line">Services</a>
        &nbsp;&nbsp;&nbsp;
        <a href="1index.php#developer-section" id="line">Developers</a>
    </div>
</footer>