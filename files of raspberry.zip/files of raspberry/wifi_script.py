import os
import time

while True:
    os.system("sudo cp ../../../etc/wpa_supplicant/wpa_supplicant.conf .")
    
    time.sleep(3)


