[For WIFI SERVER OF RPI]
Copy the files to the server of rasp: 
- index.php
- rasp.css
[For the Coins Script]
Autorun in startup the files:
- coin_script.py
- wifi_script.py